/*jshint esversion: 6 */
//const mongoose = require('mongoose');
//mongoose.connect('mongodb://localhost/directory-app');

const MongoClient = require('mongodb').MongoClient;

const uri = "mongodb://dkmullen:dorun7@cluster-dkm-shard-00-00-wpeiv.mongodb.net:27017,cluster-dkm-shard-00-01-wpeiv.mongodb.net:27017,cluster-dkm-shard-00-02-wpeiv.mongodb.net:27017/admin?ssl=true&replicaSet=cluster-dkm-shard-0&authSource=admin";

MongoClient.connect(uri, function(err, db) {
  db.close();
});
